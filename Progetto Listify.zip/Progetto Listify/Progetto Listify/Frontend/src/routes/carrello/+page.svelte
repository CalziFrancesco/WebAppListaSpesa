<script>
    import Card from "$lib/Card.svelte";
    let { data } = $props();

    /* const groupedByCategory = data.default.reduce((acc, item) => {
    const cat = item.pcategory;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {}); */
</script>
{#each Object.entries(groupedByCategory) as [category, items]}
  <!-- <h2 class="section-title">{category}</h2> -->
<div class="cardList">
    {#each data.data.carrello as lista}
            <Card lista={lista} />
    {/each}
</div>
{/each}
{#if data.data.carrello.length === 0}
    <p class="pMedio">La lista è vuota</p>
{/if}
{#if data.data.carrello.length > 0}
    <p class="pMedio">La lista contiene {data.data.carrello.length} prodotti</p>
{/if}
{#if data.data.carrello.length > 0}
    <p class="pMedio">Il costo della spesa previsto è di {data.data.carrello.reduce((acc, item) => acc + item.price, 0)}€</p>
{/if}


<style>
    .cardList{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .pMedio {
        text-align: center;
    }
</style>
