<script>
    let { lista } = $props();
</script>

<div class="card">
    <h3>{lista.pname}</h3>
    <p>Quantita: {lista.quantity} pz</p>
    <p>Marca: {lista.pbrand} </p>
</div>

<style>
    .card {
        margin-top: 20px;
        border: 1px solid black;
        padding: 10px;
        border-radius: 10px;
        background-color: azure;
    }
</style>
