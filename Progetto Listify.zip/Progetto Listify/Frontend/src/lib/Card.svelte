<script>
    let { lista } = $props();
</script>

<div class="card">
    <div class="image">
      <img src={lista.imUrl} alt={lista.pname} />
    </div>
    <div class="info">
      <div class="title">{lista.pname}</div>
      <div class="quantity-control">
        Quantità: <button>-</button> {lista.quant} <button>+</button>
      </div>
      <div class="brand">Marca: {lista.pbrand}</div>
      <a href="#" class="remove">Rimuovi</a>
    </div>
    <div class="price">
      <div class="unit-price">{lista.price}</div>
      <label>
        Preso: <input type="checkbox" bind:checked={lista.taken} />
      </label>
    </div>
  </div>

<style>
    .card {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      border: 1px solid #ddd;
      padding: 1rem;
      margin-bottom: 1rem;
      border-radius: 8px;
      background-color: white;
    }
    
    .image img {
      width: 80px;
      height: auto;
      border-radius: 4px;
    }
    
    .info {
      flex: 1;
      margin-left: 1rem;
    }
    
    .title {
      font-weight: bold;
    }
    
    .quantity-control {
      margin: 0.5rem 0;
    }
    
    .remove {
      color: red;
      text-decoration: none;
      font-size: 0.9rem;
    }
    
    .price {
      text-align: right;
      min-width: 90px;
    }
    
    .unit-price {
      font-weight: bold;
      font-size: 1rem;
      margin-bottom: 0.5rem;
    }
    </style>
