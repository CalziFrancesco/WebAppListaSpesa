<script>
    import Card from "$lib/Card.svelte";
    let { data } = $props();

    let state = $state({ aPrice: 0 });
</script>

<div class="cardList">
    {#each data.data.carrello as lista}
            <Card lista={lista} />
    {/each}
</div>


<style>
    .cardList{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
    }
    .pMedio {
        text-align: center;
    }
</style>
