export const load = async ({fetch}) => {
    const response = await fetch(`/carrello.json`);
    if(!response.ok){
        throw new Error(`Failed to fetch`);
    }
    const responseBody = await response.json();
    console.log("Sono qui!");
    console.log(responseBody);
    return {data : responseBody}
}